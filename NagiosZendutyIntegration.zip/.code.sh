#!/bin/bash

curlToZenduty(){
	return_status=$(curl -s -X POST -d "@.data.json" "$1")
	for(( i=1; i<5; i++))
	do
		if [ $return_status == "OK" ]
		then
			break
		fi
		return_status=$(curl -s -X POST -d "@.data.json" "$1")
	done
	if [ "$return_status" != "OK" ]
	then
		echo "ERROR! Either URL entered is wrong or servers are down currently. Start the program again, re-entering the URL."
		exit 0
	fi
}

touch .data.json
touch .diffs
touch .trial.log
nagiosLogFile='/usr/local/nagios/var/nagios.log'
if [ -s .trial.log ]
then
	cp $nagiosLogFile .trial.log
fi
while true
do
	change=$(diff $nagiosLogFile .trial.log)
	if [ -z "$change" ]
	then
		sleep 10
		continue
	fi
	diff $nagiosLogFile .trial.log > .diffs
	file='.diffs'
	IFS=' '
	while read i
	do
		foundCRITICAL=$(grep -c "CRITICAL;" <<< $i)
		foundOK=$(grep -c "OK;" <<< $i)
		foundUNKNOWN=$(grep -c "UNKNOWN;" <<< $i)
		foundWARNING=$(grep -c "WARNING;" <<< $i)
		foundSTART=$(grep -c "Nagios .* starting" <<< $i)
		foundEND=$(grep -c "Successfully shutdown..." <<< $i)
		foundNonInfoAlert=$(($foundCRITICAL+$foundOK+$foundUNKNOWN+$foundWARNING))

		template='{"message":"%s",\n"summary":"%s",\n"alert_type":"%s",\n"entity_id":"%s"}'
		if [ $foundNonInfoAlert != 0 ]
		then 
			IFS=':'
			read rand msg <<< "$i"
			IFS=';'
			read -ra arr <<< "$msg"
			IFS=' '
			printf "$template" "${arr[0]}" "${arr[5]}" "${arr[2]}" "${arr[1]}-${arr[0]}" > .data.json
			curlToZenduty $1

		elif [ $foundSTART != 0 ]
		then
			IFS=' '
			read -ra arr <<< "$i"
			printf "$template" "Nagios running" "${arr[2]} ${arr[3]} ${arr[4]}" "WARNING" "Nagios" > .data.json
			curlToZenduty $1

		elif [ $foundEND != 0 ]
		then
			IFS=' '
			read -ra arr <<< "$i"
			printf "$template" "Nagios stopped" "${arr[2]} ${arr[3]}" "WARNING" "Nagios" > .data.json
			curlToZenduty $1
		fi

	done < $file
	cp $nagiosLogFile .trial.log
done
echo "Program has ENDED"